package com.alicedeveloppementweb.tp_automatisation_tests;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TpAutomatisationTestsApplication {

	public static void main(String[] args) {
		SpringApplication.run(TpAutomatisationTestsApplication.class, args);
	}

}
