package com.alicedeveloppementweb.tp_automatisation_tests;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TpAutomatisationTestsApplicationTests {

	@Test
	void contextLoads() {
	}

}
